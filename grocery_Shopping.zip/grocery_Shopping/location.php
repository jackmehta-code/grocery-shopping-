<?php
// Start the session
session_start();

// Function to get the user's IP address
function getIPAddress() {
    // Check for shared Internet/ISP IP
    if (!empty($_SERVER['HTTP_CLIENT_IP']) && validateIP($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }

    // Check for IP addresses from proxy
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Check if multiple IP addresses exist in the HTTP_X_FORWARDED_FOR header
        $ipAddresses = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        foreach ($ipAddresses as $ip) {
            if (validateIP($ip)) {
                return $ip;
            }
        }
    }

    // Check for remote address
    if (!empty($_SERVER['REMOTE_ADDR']) && validateIP($_SERVER['REMOTE_ADDR'])) {
        return $_SERVER['REMOTE_ADDR'];
    }

    // Return unreliable IP address since all else failed
    return 'Unknown';
}

// Function to validate an IP address
function validateIP($ip) {
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return false;
    }
    return true;
}

// Get the user's IP address
$ip = getIPAddress();

// Query the IP geolocation service
$details = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"));

// Access the location details
$latitude = $details->lat;
$longitude = $details->lon;

// Store latitude and longitude in session variables
$_SESSION['latitude'] = $latitude;
$_SESSION['longitude'] = $longitude;
echo "Latitude: $latitude<br>";
echo "Longitude: $longitude<br>";
?>
